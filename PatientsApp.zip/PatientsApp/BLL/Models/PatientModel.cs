﻿using BLL.DAL;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Models
{
    public class PatientModel
    {
        public Patient Record { get; set; }
        public int Id => Record.Id;
        public string Name => Record.Name;
        public string Surname => Record.Surname;

        public bool IsFemale => Record.IsFemale;

        public DateTime BirthDate => (DateTime)Record.BirthDate;

        public decimal Height => (decimal)Record.Height;
        public decimal Weight => (decimal)Record.Weight;
    }
}
