﻿using BLL.DAL;
using BLL.Models;
using BLL.Services.Bases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Services
{
    public interface IPatientService
    {
        public IQueryable<PatientModel> Query();

        public ServiceBase Create(Patient record);
        public ServiceBase Update(Patient record);
        public ServiceBase Delete(int id);
    }
    public class PatientService : ServiceBase, IPatientService
    {
        public PatientService(Db db) : base(db)
        {
        }
        public IQueryable<PatientModel> Query()
        {
            //
            return _db.Patient.OrderBy(s => s.Id).Select(s => new PatientModel() );

        }
        public ServiceBase Create(Patient record)
        {
            _db.Patient.Add(record);
            return Success("Patient created succesfully");
        }
        public ServiceBase Update(Patient record)
        {
            var entity = _db.Patient.Find(record.Id);
            if (entity is null)
                return Error("Patient can't be found!");
            _db.Patient.Update(entity);
            _db.SaveChanges();
            return Success("Patient updated successfully");
        }
        public ServiceBase Delete(int id)
        {
            var entity = _db.Patient.SingleOrDefault(s => s.Id == id);
            if (entity is null) return Error("Patient cant be found");

            _db.Patient.Remove(entity);
            _db.SaveChanges();
            return Success("Patient deleted succesfully");
        }


    }
}
