﻿using BLL.DAL;
using BLL.Models;
using BLL.Services.Bases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Services
{
    public interface IDoctorService
    {
        public IQueryable<DoctorModel> Query();

        public ServiceBase Create(Doctor record);
        public ServiceBase Update(Doctor record);
        public ServiceBase Delete(int id);
    }
    public class DoctorService : ServiceBase, IDoctorService
    {
        public DoctorService(Db db) : base(db)
        {
        }
        public IQueryable<DoctorModel> Query()
        {
            //
            return _db.Doctor.OrderBy(s => s.Id).Select(s => new DoctorModel() );

        }
        public ServiceBase Create(Doctor record)
        {
            _db.Doctor.Add(record);
            return Success("Doctor created succesfully");
        }
        public ServiceBase Update(Doctor record)
        {
            var entity = _db.Doctor.Find(record.Id);
            if (entity is null)
                return Error("Doctor can't be found!");
            _db.Doctor.Update(entity);
            _db.SaveChanges();
            return Success("Doctor updated successfully");
        }
        public ServiceBase Delete(int id)
        {
            var entity = _db.Doctor.SingleOrDefault(s => s.Id == id);
            if (entity is null) return Error("Doctor cant be found");

            _db.Doctor.Remove(entity);
            _db.SaveChanges();
            return Success("Doctor deleted succesfully");
        }

       
    }
}
