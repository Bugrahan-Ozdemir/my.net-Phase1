﻿using BLL.DAL;
using BLL.Models;
using BLL.Services.Bases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Services
{
    public interface IBranchService
    {
        public IQueryable<BranchModel> Query();

        public ServiceBase Create(Branch record);
        public ServiceBase Update(Branch record);
        public ServiceBase Delete(int id);
    }
    public class BranchService : ServiceBase, IBranchService
    {
        public BranchService(Db db) : base(db)
        {
        }
        public IQueryable<BranchModel> Query()
        {
            //
            return _db.Branch.OrderBy(s => s.Id).Select(s => new BranchModel());

        }
        public ServiceBase Create(Branch record)
        {
            _db.Branch.Add(record);
            return Success("Branch created succesfully");
        }
        public ServiceBase Update(Branch record)
        {
            var entity = _db.Branch.Find(record.Id);
            if (entity is null)
                return Error("Branch can't be found!");
            _db.Branch.Update(entity);
            _db.SaveChanges();
            return Success("Branch updated successfully");
        }
        public ServiceBase Delete(int id)
        {
            var entity = _db.Branch.SingleOrDefault(s => s.Id == id);
            if (entity is null) return Error("Branch cant be found");

            _db.Branch.Remove(entity);
            _db.SaveChanges();
            return Success("Branch deleted succesfully");
        }


    }
}
