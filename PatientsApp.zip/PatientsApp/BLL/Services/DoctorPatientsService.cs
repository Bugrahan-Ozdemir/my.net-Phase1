﻿using BLL.DAL;
using BLL.Models;
using BLL.Services.Bases;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Services
{
    public interface IDoctorPatientsService
    {
        public IQueryable<DoctorPatientsModel> Query();

        public ServiceBase Create(DoctorPatient record);
        public ServiceBase Update(DoctorPatient record);
        public ServiceBase Delete(int id);
    }
        public class DoctorPatientsService : ServiceBase, IDoctorPatientsService
        {
            public DoctorPatientsService(Db db) : base(db)
            {
            }

            public IQueryable<DoctorPatientsModel> Query()
            {

                return _db.DoctorPatient.OrderBy(s => s.PatientId).Select(s => new DoctorPatientsModel() { Record = s });
            }

            public ServiceBase Create(DoctorPatient record)
            {
                _db.DoctorPatient.Add(record);
                return Success("Record created succesfully");
            }

            public ServiceBase Update(DoctorPatient record)
            {
                var entity = _db.DoctorPatient.Find(record.Id);
                if (entity is null)
                    return Error("Item can't be found!"); 
                _db.DoctorPatient.Update(entity);
                _db.SaveChanges();
                return Success("Item updated successfully");
            }
            public ServiceBase Delete(int id)
            {
              var entity = _db.DoctorPatient.SingleOrDefault(s => s.Id == id);
                if (entity is null) return Error("Item cant be found");

                _db.DoctorPatient.Remove(entity);
                _db.SaveChanges();
                return Success("Item deleted succesfully");
            }


        }
    }

